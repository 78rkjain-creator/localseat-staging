import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { canViewAllPeople, isReadOnly, hasMinimumRole } from "@/lib/permissions";
import { getPersonDetail, getCampaignTags } from "@/lib/people";
import { deriveSupportBadge } from "@/lib/support-badge";
import { db } from "@/lib/db";
import { Card } from "@/components/ui/card";
import { SupportLevelBadge, OutcomeBadge } from "@/components/ui/badge";
import { TagChip } from "@/components/ui/tag-chip";
import { AddNoteForm } from "./add-note-form";
import { PersonEditForm } from "./person-edit-form";
import { AddressEditButton } from "./address-edit-button";
import { MapPin, Navigation, Phone, MessageSquare } from "lucide-react";
import { ContactDropdown } from "./contact-dropdown";
import type { SupportLevel, CanvassOutcome, OutreachChannel, ListSource } from "@/types";
import { OUTREACH_CHANNEL_LABELS, LIST_SOURCE_LABELS } from "@/types";
import { CustomFieldsEditor } from "./custom-fields-editor";
import type { CustomField } from "./custom-fields-editor";
import { ListSourceToggle } from "./list-source-toggle";
import { PersonTagEditor } from "./person-tag-editor";
import { OutOfDistrictControl } from "./out-of-district-control";
import { SignatureSection } from "./signature-section";
import { saveSignature } from "./signature-actions";
import { AnonymizeButton } from "./anonymize-button";
import { TeamLinkButton } from "./team-link-button";
import { GeocodeButton } from "./geocode-button";
import { PromoteToUserButton } from "./promote-to-user-button";
import type { AvailableMember } from "./team-link-button";
import { ROLE_LABELS } from "@/types";

interface PageProps {
  params: Promise<{ personId: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  await params;
  return { title: "Person" };
}

export default async function PersonDetailPage({ params }: PageProps) {
  const { personId } = await params;

  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  const { activeCampaignId, activeRole } = session.user;
  if (!activeCampaignId) redirect("/select-campaign");
  if (activeRole && !canViewAllPeople(activeRole as import("@/types").Role)) redirect("/dashboard");
  const baseReadOnly = activeRole ? isReadOnly(activeRole as import("@/types").Role) : false;
  const canAnonymize = activeRole === "candidate" || activeRole === "campaign_manager" || activeRole === "data_manager";
  const canToggleWalkList = activeRole
    ? hasMinimumRole(activeRole as import("@/types").Role, "field_organizer" as import("@/types").Role)
    : false;
  const canEditTags = activeRole
    ? hasMinimumRole(activeRole as import("@/types").Role, "field_organizer" as import("@/types").Role)
    : false;
  const canMarkOod = activeRole
    ? hasMinimumRole(activeRole as import("@/types").Role, "field_organizer" as import("@/types").Role)
    : false;
  const canRemoveOod =
    activeRole === "candidate" || activeRole === "campaign_manager" || activeRole === "data_manager";

  const canLinkTeamMember = canAnonymize; // candidate + campaign_manager only
  const canEditFullPii = canAnonymize; // candidate/campaign_manager/data_manager
  const canEditSupportLevel = canToggleWalkList; // field_organizer+

  const [person, campaign, listMemberships, campaignTags, signatures, consentTypes] = await Promise.all([
    getPersonDetail(personId, activeCampaignId),
    db.campaign.findUnique({
      where: { id: activeCampaignId },
      select: { customFields: true },
    }),
    db.personListMembership.findMany({
      where: { personId, campaignId: activeCampaignId },
      select: {
        id: true,
        status: true,
        listImport: {
          select: { id: true, name: true, importedAt: true, type: true },
        },
      },
      orderBy: { createdAt: "desc" },
    }),
    getCampaignTags(activeCampaignId),
    db.signatureRecord.findMany({
      where: { personId, campaignId: activeCampaignId },
      select: {
        id: true,
        purpose: true,
        signatureData: true,
        collectedAt: true,
        collectedBy: { select: { firstName: true, lastName: true } },
        consentItems: { select: { consentType: { select: { label: true } } } },
      },
      orderBy: { collectedAt: "desc" },
    }),
    db.signatureConsentType.findMany({
      where: { campaignId: activeCampaignId, deletedAt: null },
      select: { id: true, label: true },
      orderBy: { sortOrder: "asc" },
    }),
  ]);
  if (!person) notFound();

  // Touch count: canvass + outreach already loaded by getPersonDetail; events optional via userId
  const canvassCount  = person.canvassResponses.length;
  const outreachCount = person.outreachLogs.length; // already filtered deletedAt: null
  const eventCount = person.userId
    ? await db.eventAttendee.count({
        where: { userId: person.userId, deletedAt: null, event: { campaignId: activeCampaignId } },
      })
    : 0;
  const touchCount = canvassCount + outreachCount + eventCount;

  // Fetch available team members for the link dropdown (two-step to avoid unsupported nested filter)
  let availableMembers: AvailableMember[] = [];
  if (canLinkTeamMember) {
    const alreadyLinked = await db.person.findMany({
      where: { campaignId: activeCampaignId, deletedAt: null, userId: { not: null } },
      select: { userId: true },
    });
    const linkedUserIds = alreadyLinked.map((p) => p.userId as string);

    const rawMembers = await db.campaignMembership.findMany({
      where: {
        campaignId: activeCampaignId,
        deletedAt: null,
        userId: { notIn: linkedUserIds },
      },
      select: {
        role: true,
        user: { select: { id: true, firstName: true, lastName: true, email: true } },
      },
      orderBy: [{ user: { lastName: "asc" } }],
    });
    availableMembers = rawMembers.map((m) => ({
      userId: m.user.id,
      firstName: m.user.firstName,
      lastName: m.user.lastName,
      email: m.user.email,
      role: m.role,
    }));
  }

  const canSeeCustomFields =
    activeRole === "candidate" ||
    activeRole === "campaign_manager" ||
    activeRole === "data_manager" ||
    activeRole === "co_chair" ||
    activeRole === "field_organizer";

  const address = person.household?.address;
  const householdMembers = person.household?.people ?? [];

  type TimelineEvent =
    | { type: "canvass"; date: Date; data: (typeof person.canvassResponses)[number] }
    | { type: "outreach"; date: Date; data: (typeof person.outreachLogs)[number] };

  const timeline: TimelineEvent[] = [
    ...person.canvassResponses.map((r) => ({
      type: "canvass" as const,
      date: new Date(r.respondedAt),
      data: r,
    })),
    ...person.outreachLogs.map((l) => ({
      type: "outreach" as const,
      date: new Date(l.date),
      data: l,
    })),
  ].sort((a, b) => b.date.getTime() - a.date.getTime());

  const latestCanvass = person.canvassResponses[0];
  const linkedDonor = person.linkedDonors[0] ?? null;

  const customFieldDefs = (campaign?.customFields as CustomField[] | null) ?? [];
  const customFieldValues = (person.customFieldValues as Record<string, string> | null) ?? {};

  const residentListMemberships = listMemberships.filter(
    (m) => m.listImport.type === "list" || m.listImport.type === "telephone_list"
  );
  const voterListMemberships = listMemberships.filter(
    (m) =>
      m.listImport.type === "official_voters_list" &&
      (m.status === "matched" || m.status === "created" || m.status === "accepted")
  );

  const isTeamMember = !!person.userId;
  const linkedRole = person.user?.memberships?.[0]?.role ?? null;
  const isVolunteer = person.volunteerRecords.length > 0;
  const canPromoteToUser = canAnonymize && isVolunteer && !isTeamMember && !!person.email;

  const p = person as typeof person & { anonymizedAt: Date | null };

  const isAnonymized = !!p.anonymizedAt;
  const readOnly = baseReadOnly || isAnonymized;

  return (
    <div className="px-4 sm:px-6 py-8 max-w-4xl mx-auto">
      {/* Back link */}
      <Link
        href="/people/residents"
        className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-700 mb-6"
      >
        <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
        </svg>
        People
      </Link>

      {/* Person header */}
      <div className="flex items-start gap-4 mb-6">
        <div className="h-16 w-16 rounded-2xl bg-slate-100 flex items-center justify-center flex-shrink-0">
          <span className="text-xl font-bold text-slate-500">
            {person.firstName[0]}{person.lastName[0]}
          </span>
        </div>
        <div className="min-w-0 flex-1 pt-1">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-2xl font-bold text-slate-900">
              {person.firstName} {person.lastName}
            </h1>
            {person.isConfirmedVoter && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                Confirmed voter
              </span>
            )}
            {isTeamMember && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-violet-50 text-violet-700 border border-violet-200">
                Team{linkedRole ? ` · ${ROLE_LABELS[linkedRole as import("@/types").Role] ?? linkedRole}` : ""}
              </span>
            )}
            {isVolunteer && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                Volunteer
              </span>
            )}
            {isAnonymized && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-500 border border-slate-200">
                Anonymized
              </span>
            )}
            <ListSourceBadge source={person.listSource as ListSource} />
            {!isAnonymized && <WardStatusBadge wardStatus={person.wardStatus} />}
            {!isAnonymized && (
              <GeocodedBadge
                lat={address?.lat ?? null}
                lng={address?.lng ?? null}
                hasAddress={!!address}
              />
            )}
          </div>
          {address && (
            <div className="flex items-center gap-2 flex-wrap mt-0.5">
              <p className="text-slate-500">
                {address.streetNumber} {address.streetName}
                {address.unitNumber ? ` #${address.unitNumber}` : ""},{" "}
                {address.city}
              </p>
              <a
                href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${address.streetNumber} ${address.streetName}${address.unitNumber ? ` #${address.unitNumber}` : ""}, ${address.city}, ${address.province}`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-brand-600 transition-colors"
              >
                <MapPin className="h-3.5 w-3.5" />
                Navigate
              </a>
            </div>
          )}
          {person.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-2">
              {person.tags.map(({ tag }) => (
                <TagChip
                  key={tag.id}
                  name={tag.name}
                  color={tag.color}
                  tagId={tag.id}
                />
              ))}
            </div>
          )}
          {!isAnonymized && (
            <p className="text-xs text-slate-500 mt-2">
              {touchCount === 0 ? (
                <span className="text-slate-400">No touches</span>
              ) : (
                <>
                  <strong className="text-slate-700">{touchCount}</strong>
                  {" touch"}{touchCount !== 1 ? "es" : ""}{" "}
                  <span className="text-slate-400">
                    ({canvassCount} canvass, {outreachCount} outreach{eventCount > 0 ? `, ${eventCount} events` : ""})
                  </span>
                </>
              )}
            </p>
          )}
          {canAnonymize && !isAnonymized && (
            <div className="mt-3">
              <AnonymizeButton
                personId={person.id}
                personName={`${person.firstName} ${person.lastName}`}
              />
            </div>
          )}
          {canLinkTeamMember && !isAnonymized && (
            <TeamLinkButton
              personId={person.id}
              linkedUserId={person.userId ?? null}
              linkedRole={linkedRole}
              availableMembers={availableMembers}
            />
          )}
          {!isAnonymized && canToggleWalkList && (
            <GeocodeButton
              personId={person.id}
              lat={address?.lat ?? null}
              lng={address?.lng ?? null}
              wardStatus={person.wardStatus}
              hasCompleteAddress={!!(address?.streetNumber && address?.streetName && address?.city)}
            />
          )}
          {!isAnonymized && canPromoteToUser && (
            <PromoteToUserButton
              personId={person.id}
              personName={`${person.firstName} ${person.lastName}`}
              personEmail={person.email!}
            />
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left column: contact + status */}
        <div className="lg:col-span-1 flex flex-col gap-4">
          {/* Contact info */}
          <Card padding="md">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide">Contact</h2>
              {(person.phoneHome || person.phoneMobile || person.email) && !isAnonymized && (
                <ContactDropdown
                  phoneHome={person.phoneHome}
                  phoneMobile={person.phoneMobile}
                  email={person.email}
                />
              )}
            </div>
            <PersonEditForm
              personId={person.id}
              firstName={person.firstName}
              lastName={person.lastName}
              email={person.email}
              phoneHome={person.phoneHome}
              phoneMobile={person.phoneMobile}
              birthDate={person.birthDate}
              supportLevel={person.supportLevel}
              pollNumber={person.pollNumber ?? null}
              availability={person.availability ?? null}
              wardStatus={person.wardStatus}
              readOnly={readOnly}
              address={address ? {
                streetNumber: address.streetNumber,
                streetName: address.streetName,
                unitNumber: address.unitNumber,
                city: address.city,
                province: address.province,
                postalCode: address.postalCode,
              } : undefined}
              userId={person.userId ?? null}
              isVolunteer={person.volunteerRecords.length > 0}
              hasDonorInterest={person.linkedDonors.length > 0}
              canEditFullPii={canEditFullPii}
              canEditSupportLevel={canEditSupportLevel}
            />
            {(person.phoneHome || person.phoneMobile) && (
              <div className="flex flex-col gap-2 mt-3 pt-3 border-t border-slate-100">
                {person.phoneHome && (
                  <div className="flex items-center gap-2">
                    <Phone className="h-3.5 w-3.5 text-slate-400 flex-shrink-0" />
                    <a href={`tel:${person.phoneHome}`} className="text-sm text-brand-600 hover:underline flex-1 min-w-0 truncate">
                      {person.phoneHome}
                    </a>
                    <a href={`sms:${person.phoneHome}`} aria-label={`SMS ${person.phoneHome}`} className="flex-shrink-0 text-slate-400 hover:text-slate-600 transition-colors">
                      <MessageSquare className="h-3.5 w-3.5" />
                    </a>
                  </div>
                )}
                {person.phoneMobile && person.phoneMobile !== person.phoneHome && (
                  <div className="flex items-center gap-2">
                    <Phone className="h-3.5 w-3.5 text-slate-400 flex-shrink-0" />
                    <a href={`tel:${person.phoneMobile}`} className="text-sm text-brand-600 hover:underline flex-1 min-w-0 truncate">
                      {person.phoneMobile}
                    </a>
                    <a href={`sms:${person.phoneMobile}`} aria-label={`SMS ${person.phoneMobile}`} className="flex-shrink-0 text-slate-400 hover:text-slate-600 transition-colors">
                      <MessageSquare className="h-3.5 w-3.5" />
                    </a>
                  </div>
                )}
              </div>
            )}
            {person.outreachLogs[0] && (
              <p className="text-xs text-slate-400 mt-3 pt-3 border-t border-slate-100">
                Last contacted:{" "}
                <span className="text-slate-600">
                  {OUTREACH_CHANNEL_LABELS[person.outreachLogs[0].channel as OutreachChannel] ?? person.outreachLogs[0].channel}
                  {" · "}
                  {formatDate(new Date(person.outreachLogs[0].date))}
                </span>
              </p>
            )}
            {person.importSource && (
              <p className="text-xs text-slate-400 mt-3 pt-3 border-t border-slate-100">
                Source: {person.importSource}
              </p>
            )}
            {person.listSource === "manual" && canToggleWalkList && (
              <ListSourceToggle
                personId={person.id}
                initialValue={person.includeInWalkLists}
              />
            )}
            {!isTeamMember && (canMarkOod || person.isOutOfDistrict) && (
              <OutOfDistrictControl
                personId={person.id}
                isOutOfDistrict={person.isOutOfDistrict}
                canMark={canMarkOod}
                canRemove={canRemoveOod}
              />
            )}
          </Card>

          {/* Support status */}
          {(latestCanvass || person.supportLevel) && (
            <Card padding="md">
              <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-3">
                {latestCanvass ? "Canvass status" : "Support level"}
              </h2>
              <div className="flex flex-col gap-2">
                {latestCanvass && (
                  <OutcomeBadge outcome={latestCanvass.outcome as CanvassOutcome} />
                )}
                {latestCanvass?.outcome === "other_candidate" && latestCanvass.competitor?.name && (
                  <p className="text-xs text-slate-500">
                    Supporting: {latestCanvass.competitor.name}
                  </p>
                )}
                {(() => {
                  const badge = deriveSupportBadge({
                    latestCanvassSupport: latestCanvass?.supportLevel as SupportLevel ?? null,
                    importedSupport: person.supportLevel as SupportLevel ?? null,
                  });
                  return badge ? (
                    <SupportLevelBadge level={badge.level} source={badge.source} />
                  ) : null;
                })()}
                {latestCanvass && (latestCanvass.signRequest || latestCanvass.volunteerInterest || latestCanvass.donorInterest) && (
                  <div className="flex flex-wrap gap-2 mt-1">
                    {latestCanvass.signRequest && (
                      <FlagChip label="Yard sign" color="blue" />
                    )}
                    {latestCanvass.volunteerInterest && (
                      <FlagChip label="Volunteer" color="green" />
                    )}
                    {latestCanvass.donorInterest && (
                      <FlagChip label="Donor interest" color="orange" />
                    )}
                  </div>
                )}
              </div>
            </Card>
          )}

          {/* Donor link */}
          {linkedDonor && (
            <Card padding="md">
              <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-3">
                Donor
              </h2>
              <Link
                href={`/donors/${linkedDonor.id}`}
                className="text-sm text-brand-600 hover:underline"
              >
                View donor record
              </Link>
              <p className="text-xs text-slate-400 mt-1 capitalize">{linkedDonor.status}</p>
            </Card>
          )}

          {/* Household */}
          {person.household && (
            <Card padding="md">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide">
                  Household
                </h2>
                {!readOnly && address && (
                  <AddressEditButton
                    personId={person.id}
                    campaignId={activeCampaignId}
                    currentAddress={address}
                    householdMembers={householdMembers}
                  />
                )}
              </div>
              {address && (
                <div className="flex items-start gap-2 mb-2">
                  <p className="text-sm text-slate-600 flex-1">
                    {address.streetNumber} {address.streetName}
                    {address.unitNumber ? ` #${address.unitNumber}` : ""}
                    <br />
                    {address.city}, {address.province} {address.postalCode}
                  </p>
                  <a
                    href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${address.streetNumber} ${address.streetName}${address.unitNumber ? ` #${address.unitNumber}` : ""}, ${address.city}, ${address.province} ${address.postalCode}`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 h-8 px-2.5 rounded-xl border border-slate-200 text-xs text-slate-600 hover:bg-slate-50 flex-shrink-0 transition-colors"
                  >
                    <Navigation className="h-3.5 w-3.5" />
                    Navigate
                  </a>
                </div>
              )}
              {householdMembers.length > 0 && (
                <div className="flex flex-col gap-1.5">
                  <p className="text-xs font-medium text-slate-400 uppercase tracking-wide">
                    Also at this address
                  </p>
                  {householdMembers.map((m) => (
                    <Link
                      key={m.id}
                      href={`/people/${m.id}`}
                      className="text-sm text-brand-600 hover:underline"
                    >
                      {m.firstName} {m.lastName}
                    </Link>
                  ))}
                </div>
              )}
            </Card>
          )}

          {/* Open tasks */}
          {person.tasks.length > 0 && (
            <Card padding="md">
              <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-3">
                Open tasks
              </h2>
              <ul className="flex flex-col gap-2.5">
                {person.tasks.map((task) => (
                  <li key={task.id} className="flex items-start gap-2">
                    <div className="h-4 w-4 rounded border border-slate-300 mt-0.5 flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm text-slate-800">{task.title}</p>
                      {task.dueDate && (
                        <p className={[
                          "text-xs mt-0.5",
                          new Date(task.dueDate) < new Date()
                            ? "text-red-500"
                            : "text-slate-400",
                        ].join(" ")}>
                          Due {formatDate(new Date(task.dueDate))}
                        </p>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </div>

        {/* Right column: tags + notes + list membership + timeline */}
        <div className="lg:col-span-2 flex flex-col gap-4">
          {/* Tags */}
          <Card padding="md">
            <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-3">
              Tags
            </h2>
            <PersonTagEditor
              personId={person.id}
              initialTags={person.tags.map(({ tag }) => tag)}
              campaignTags={campaignTags}
              canEdit={canEditTags}
            />
          </Card>

          {/* Notes */}
          <Card padding="md">
            <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-4">
              Notes
            </h2>

            {person.notes.length > 0 && (
              <ul className="flex flex-col gap-4 mb-5">
                {person.notes.map((note) => (
                  <li key={note.id} className="flex flex-col gap-1">
                    <p className="text-sm text-slate-800 whitespace-pre-wrap leading-relaxed">
                      {note.body}
                    </p>
                    <p className="text-xs text-slate-400">
                      {note.author.firstName} {note.author.lastName} &middot;{" "}
                      {formatDate(new Date(note.createdAt))}
                    </p>
                  </li>
                ))}
              </ul>
            )}

            {!readOnly && <AddNoteForm personId={person.id} />}
          </Card>

          {/* Custom fields */}
          {canSeeCustomFields && (
            <Card padding="md">
              <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-4">
                Custom fields
              </h2>
              <CustomFieldsEditor
                personId={person.id}
                fields={customFieldDefs}
                values={customFieldValues}
                readOnly={readOnly}
              />
            </Card>
          )}

          {/* Residents List */}
          <Card padding="md">
            <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-4">
              Residents List
            </h2>
            {residentListMemberships.length === 0 ? (
              <p className="text-sm text-slate-400">No lists on record.</p>
            ) : (
              <ul className="flex flex-col divide-y divide-slate-100">
                {residentListMemberships.map((m) => (
                  <li key={m.id} className="flex items-center justify-between py-2 first:pt-0 last:pb-0">
                    <span className="text-sm text-slate-800">{m.listImport.name}</span>
                    <span className="text-xs text-slate-400 flex-shrink-0 ml-4">
                      {formatDate(new Date(m.listImport.importedAt))}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          {/* Voter List */}
          <Card padding="md">
            <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-4">
              Voter List
            </h2>
            {voterListMemberships.length === 0 ? (
              <p className="text-sm text-slate-400">No voter list data uploaded yet.</p>
            ) : (
              <ul className="flex flex-col divide-y divide-slate-100">
                {voterListMemberships.map((m) => (
                  <li key={m.id} className="flex items-center justify-between py-2 first:pt-0 last:pb-0">
                    <span className="text-sm text-slate-800">{m.listImport.name}</span>
                    <span className="text-xs text-slate-400 flex-shrink-0 ml-4">
                      {formatDate(new Date(m.listImport.importedAt))}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          {/* Signatures */}
          <Card padding="md">
            <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-4">
              Signatures
            </h2>
            <SignatureSection
              personId={person.id}
              signatures={signatures}
              consentTypes={consentTypes}
              onSave={saveSignature}
            />
          </Card>

          {/* Activity timeline */}
          <Card padding="md">
            <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-4">
              Activity
            </h2>

            {timeline.length === 0 ? (
              <p className="text-sm text-slate-400">No activity recorded yet.</p>
            ) : (
              <ol className="relative border-l border-slate-100 ml-2 flex flex-col gap-5">
                {timeline.map((event, idx) => (
                  <li key={idx} className="pl-5 relative">
                    <div className="absolute -left-1.5 top-1 h-3 w-3 rounded-full border-2 border-white bg-slate-300" />

                    {event.type === "canvass" ? (
                      <CanvassTimelineItem event={event.data} date={event.date} />
                    ) : (
                      <OutreachTimelineItem event={event.data} date={event.date} />
                    )}
                  </li>
                ))}
              </ol>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}

// ── Sub-components ────────────────────────────────────────────────────────────

function ListSourceBadge({ source }: { source: ListSource }) {
  const colorMap: Record<ListSource, string> = {
    voters_list:    "bg-emerald-50 text-emerald-700 border-emerald-200",
    residents_list: "bg-blue-50 text-blue-700 border-blue-200",
    manual:         "bg-slate-100 text-slate-600 border-slate-200",
    canvass:        "bg-orange-50 text-orange-700 border-orange-200",
    team:           "bg-violet-50 text-violet-700 border-violet-200",
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${colorMap[source]}`}>
      {LIST_SOURCE_LABELS[source]}
    </span>
  );
}

function WardStatusBadge({ wardStatus }: { wardStatus: string }) {
  if (wardStatus === "not_checked") return null;

  const config: Record<string, { label: string; cls: string }> = {
    inside:           { label: "In area",     cls: "bg-emerald-50 text-emerald-700 border-emerald-200" },
    outside_accepted: { label: "In area",     cls: "bg-emerald-50 text-emerald-700 border-emerald-200" },
    outside:          { label: "Out of area", cls: "bg-rose-50 text-rose-700 border-rose-200" },
  };

  const entry = config[wardStatus];
  if (!entry) return null;

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${entry.cls}`}>
      {entry.label}
    </span>
  );
}

function GeocodedBadge({
  lat,
  lng,
  hasAddress,
}: {
  lat: number | null;
  lng: number | null;
  hasAddress: boolean;
}) {
  if (!hasAddress) return null;

  const geocoded = lat !== null && lng !== null;
  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${
        geocoded
          ? "bg-emerald-50 text-emerald-700 border-emerald-200"
          : "bg-amber-50 text-amber-700 border-amber-200"
      }`}
    >
      {geocoded ? "Geocoded" : "Not geocoded"}
    </span>
  );
}

function FlagChip({ label, color }: { label: string; color: "blue" | "green" | "orange" }) {
  const colorMap = {
    blue:   "bg-blue-50 text-blue-700 border-blue-200",
    green:  "bg-emerald-50 text-emerald-700 border-emerald-200",
    orange: "bg-orange-50 text-orange-700 border-orange-200",
  };
  return (
    <span className={["inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border", colorMap[color]].join(" ")}>
      {label}
    </span>
  );
}

const OUTREACH_METHOD_LABELS = OUTREACH_CHANNEL_LABELS;

function CanvassTimelineItem({
  event,
  date,
}: {
  event: { outcome: string; supportLevel?: string | null; notes?: string | null; competitor?: { name: string } | null; assignment: { canvasser: { firstName: string; lastName: string }; canvassList: { name: string } } };
  date: Date;
}) {
  return (
    <div>
      <div className="flex flex-wrap items-center gap-2 mb-1">
        <span className="text-sm font-medium text-slate-800">Door canvass</span>
        <OutcomeBadge outcome={event.outcome as CanvassOutcome} />
        {event.supportLevel && (
          <SupportLevelBadge level={event.supportLevel as SupportLevel} />
        )}
      </div>
      {event.outcome === "other_candidate" && event.competitor?.name && (
        <p className="text-xs text-slate-500 mb-1">Supporting: {event.competitor.name}</p>
      )}
      {event.notes && (
        <p className="text-sm text-slate-600 mb-1">&ldquo;{event.notes}&rdquo;</p>
      )}
      <p className="text-xs text-slate-400">
        {event.assignment.canvasser.firstName} {event.assignment.canvasser.lastName}{" "}
        &middot; {event.assignment.canvassList.name} &middot;{" "}
        {formatDate(date)}
      </p>
    </div>
  );
}

function OutreachTimelineItem({
  event,
  date,
}: {
  event: { channel: string; outcome?: string | null; notes?: string | null; user?: { firstName: string; lastName: string } | null };
  date: Date;
}) {
  return (
    <div>
      <p className="text-sm font-medium text-slate-800 mb-1">
        {OUTREACH_METHOD_LABELS[event.channel as OutreachChannel] ?? event.channel}
        {event.outcome && (
          <span className="text-slate-500 font-normal"> — {event.outcome}</span>
        )}
      </p>
      {event.notes && (
        <p className="text-sm text-slate-600 mb-1">{event.notes}</p>
      )}
      <p className="text-xs text-slate-400">
        {event.user ? `${event.user.firstName} ${event.user.lastName} · ` : ""}{formatDate(date)}
      </p>
    </div>
  );
}

function formatDate(date: Date): string {
  return date.toLocaleDateString("en-CA", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}
