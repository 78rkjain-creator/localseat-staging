import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { TeamImportClient } from "./import-client";
import { BackLink } from "@/components/ui/back-link";

export const metadata: Metadata = { title: "Import Team Members & Volunteers" };

const PERMITTED_ROLES = ["candidate", "campaign_manager", "data_manager", "co_chair", "field_organizer"] as const;
const FO_ALLOWED_NEW_ROLES = ["canvasser", "sign_installer"] as const;
const ALL_NEW_ROLES = [
  "candidate",
  "campaign_manager",
  "data_manager",
  "co_chair",
  "field_organizer",
  "canvasser",
  "volunteer_coordinator",
  "finance_lead",
  "sign_installer",
] as const;

type PermittedRole = (typeof PERMITTED_ROLES)[number];

export default async function TeamImportPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  const { activeCampaignId, activeRole } = session.user;
  if (!activeCampaignId) redirect("/select-campaign");

  if (!activeRole || !PERMITTED_ROLES.includes(activeRole as PermittedRole)) {
    return (
      <main className="max-w-3xl mx-auto px-6 py-8">
        <h1 className="text-xl font-semibold text-slate-900">Not authorized</h1>
        <p className="text-sm text-slate-500 mt-2">
          You don&apos;t have permission to import team members.
        </p>
      </main>
    );
  }

  const validRoles: string[] =
    activeRole === "field_organizer"
      ? [...FO_ALLOWED_NEW_ROLES]
      : [...ALL_NEW_ROLES];

  const tags = await db.tag.findMany({
    where: { campaignId: activeCampaignId, deletedAt: null },
    select: { id: true, name: true },
    orderBy: { name: "asc" },
  });

  return (
    <div className="px-4 sm:px-6 py-8 max-w-5xl mx-auto">
      <BackLink fallbackHref="/import" label="Back to Import & Data Management" />

      <header className="mb-6 space-y-1">
        <h1 className="text-2xl font-bold text-slate-900">Import team members & volunteers</h1>
        <p className="text-sm text-slate-500">
          Bulk-add canvassers, field organizers, volunteers, and other campaign roles.
        </p>
      </header>

      <TeamImportClient
        validRoles={validRoles}
        existingTags={tags}
        requesterRole={activeRole}
      />
    </div>
  );
}
